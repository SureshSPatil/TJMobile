package edu.tjhsst.finalproject;

import java.util.Calendar;
import java.util.Date;
/**
 * Created by 2019fahmad on 12/12/2017.
 */

public class Task implements Comparable<Task> {
        private String name;
        private int durationMins;
    private String subject;
    private Date due;


    public Task(String n, int m, String s, Date d)
    {
        name = n;
        durationMins = m;
        subject = s;
        due = d;
    }




    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDurationMins() {
        return durationMins;
    }

    public void setDurationMins(int durationMins) {
        this.durationMins = durationMins;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }


    public Date getDue() {
        return due;
    }

    public void setDue(Date due) {
        this.due = due;
    }


    public int compareTo(Task t) {

return 0;
    }
}

